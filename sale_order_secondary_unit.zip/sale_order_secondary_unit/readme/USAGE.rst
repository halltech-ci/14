To use this module you need to:

#. Go to a *Product > General Information tab*.
#. Create any record in "Secondary unit of measure".
#. Set the conversion factor.
#. Go to *Sales > Quotation > Create*.
#. Change quantities in line and secondary unit (produc_qty will be change).
