This module extends the functionality of sale orders to allow sale products in
secondary unit of distinct category.
